package com.incubeSchool;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/submitRegistration")
public class SubmitSchoolRegistration extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC database URL, username, and password of MySQL server
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/incubeDB?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "root";

    // Ensure the MySQL JDBC driver is loaded
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Retrieve form data using ternary operators
        String name = (request.getParameter("name") != null) ? request.getParameter("name") : "";
        String mobile = (request.getParameter("mobile") != null) ? request.getParameter("mobile") : "";
        String email = (request.getParameter("email") != null) ? request.getParameter("email") : "";
        String gender = (request.getParameter("gender") != null) ? request.getParameter("gender") : "";
        String course = (request.getParameter("course") != null) ? request.getParameter("course") : "";

        // Process data and insert into the database
        String registrationResult = processRegistration(name, mobile, email, gender, course);

        // Send response to the client
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Registration Summary</h2>");
        out.println("<p>Name: " + name + "</p>");
        out.println("<p>Mobile Number: " + mobile + "</p>");
        out.println("<p>Email Id: " + email + "</p>");
        out.println("<p>Gender: " + gender + "</p>");
        out.println("<p>Selected Course: " + course + "</p>");
        out.println("<p>Result: " + registrationResult + "</p>");
        out.println("</body></html>");

        // Redirect only if registration is successful
        if (registrationResult.contains("successful")) {
            response.sendRedirect("success.jsp");
        } else {
            out.println("<p>Something went wrong. Please try again.</p>");
        }
    }

    private String processRegistration(String name, String mobile, String email, String gender, String course) {
        String resultMessage;

        // JDBC variables
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            // Insert data into the database
            String sql = "INSERT INTO incubeschool (name, mobile, email, gender, course) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, name);
                statement.setString(2, mobile);
                statement.setString(3, email);
                statement.setString(4, gender);
                statement.setString(5, course);

                int rowsAffected = statement.executeUpdate();
                if (rowsAffected > 0) {
                    resultMessage = "Registration successful! Data inserted into the database.";
                } else {
                    resultMessage = "Registration failed. Please try again.";
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            resultMessage = "An error occurred while processing the registration.";
        }

        return resultMessage;
    }
}
